angular.module('juiceShop').controller('AboutController', [
  function () {}])
