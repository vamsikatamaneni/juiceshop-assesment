angular.module('juiceShop').controller('AdministrationController', [
  function () {}])
